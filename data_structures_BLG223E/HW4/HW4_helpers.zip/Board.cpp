#include <iostream>
#include "Board.h"

using namespace std;

Board::Board(int dim, int outX, int outY){
    this->DIM=dim;
    this->outX=outX;
    this->outY=outY;

    board = new char*[dim];
    for(int i=0;i<dim;i++)
        board[i] = new char[dim];

}

Board::Board(const Board &p1){
    this->DIM=p1.DIM;
    this->outX=p1.outX;
    this->outY=p1.outY;

    board = new char*[DIM];
    for(int i=0;i<DIM;i++)
        board[i] = new char[DIM];

    for(int i=0;i<DIM;i++)
        for(int j=0;j<DIM;j++)
            board[i][j]=p1.board[i][j];

    pieces = p1.pieces;
}

void Board::addPiece(Piece ap){
    this->pieces.push_back(ap);
}

void Board::buildBoard(){
    for(int i=0;i<DIM;i++)
        for(int j=0;j<DIM;j++)
            board[i][j]='_';

    for(Piece p:pieces){
        if(p.get_hor()){
            for(int i=p.get_startY();i<=p.get_endY();i++)
                board[p.get_startX()][i]=p.get_sign();
        }
        else{
            for(int i=p.get_startX();i<=p.get_endX();i++)
                board[i][p.get_startY()]=p.get_sign();
        }
    }

}

void Board::printBoard(){
    for(int i=0;i<DIM;i++){
        for(int j=0;j<DIM;j++)
            cout<<board[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl;
}

vector<Move> Board::getMoves(){
    vector<Move> moves;

    for(Piece p:pieces){
        if(p.get_hor()){
            if(p.get_startY()-1>=0 && board[p.get_startX()][p.get_startY()-1]=='_')
                moves.push_back(Move(p, LEFT));
            
            if(p.get_endY()+1<DIM && board[p.get_startX()][p.get_endY()+1]=='_')
                moves.push_back(Move(p, RIGHT));
        }
        else{
            if(p.get_startX()-1>=0 && board[p.get_startX()-1][p.get_endY()]=='_')
                moves.push_back(Move(p, UP));
            
            if(p.get_endX()+1<DIM && board[p.get_endX()+1][p.get_endY()]=='_')
                moves.push_back(Move(p, DOWN));
        }

    }

    return moves;
}

void Board::move(Move m){

    for(Piece& p:pieces){
        if(p.get_sign()==m.getpiece().get_sign())
            p.move(m.getdir());
    }

    this->buildBoard();
}

bool Board::equals(Board b){
    for(int i=0;i<DIM;i++)
        for(int j=0;j<DIM;j++)
            if(board[i][j]!=b.board[i][j])
                return false;

    return true;
}

bool Board::checkend(){
    return board[outX][outY]=='X'; 
}
#pragma once
#include "Piece.h"
#include "Move.h"
#include <vector>

using namespace std;

class Board{
    private:
        int DIM;
        int outX, outY;
        char** board;
        vector<Piece> pieces;
    public:
        Board(int,int,int);
        Board(const Board&);
        void addPiece(Piece);
        void buildBoard();
        void printBoard();
        vector<Move> getMoves();
        void move(Move);
        bool equals(Board);
        bool checkend();
};